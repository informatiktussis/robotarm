var NAVTREE =
[
  [ "Robot Arm_Arduino", "index.html", [
    [ "Project : Robot Arm", "index.html", [
      [ "Intro", "index.html#Intro", null ],
      [ "Program", "index.html#Program", null ],
      [ "InOutput", "index.html#InOutput", null ],
      [ "CreateInfo", "index.html#CreateInfo", null ],
      [ "ModifyInfo", "index.html#ModifyInfo", null ]
    ] ],
    [ "Datenstrukturen", "annotated.html", [
      [ "Datenstrukturen", "annotated.html", "annotated_dup" ],
      [ "Datenstruktur-Verzeichnis", "classes.html", null ],
      [ "Klassenhierarchie", "hierarchy.html", "hierarchy" ],
      [ "Datenstruktur-Elemente", "functions.html", [
        [ "Alle", "functions.html", null ],
        [ "Funktionen", "functions_func.html", null ],
        [ "Variablen", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Dateien", null, [
      [ "Auflistung der Dateien", "files.html", "files" ],
      [ "Datei-Elemente", "globals.html", [
        [ "Alle", "globals.html", null ],
        [ "Funktionen", "globals_func.html", null ],
        [ "Variablen", "globals_vars.html", null ],
        [ "Makrodefinitionen", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_arduino__kommentiert_8ino.html"
];

var SYNCONMSG = 'Klicken um Panelsynchronisation auszuschalten';
var SYNCOFFMSG = 'Klicken um Panelsynchronisation einzuschalten';