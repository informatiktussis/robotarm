var dir_05b75452a8a4a9efb8b89831badff345 =
[
    [ "Arduino_kommentiert.ino", "_arduino__kommentiert_8ino.html", "_arduino__kommentiert_8ino" ],
    [ "DumbServer.cpp", "_dumb_server_8cpp.html", "_dumb_server_8cpp" ],
    [ "DumbServer.h", "_dumb_server_8h.html", [
      [ "EspServer", "class_esp_server.html", "class_esp_server" ]
    ] ]
];