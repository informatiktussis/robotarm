var searchData=
[
  ['_5fesp_5fserial',['_esp_serial',['../class_esp_server.html#a552aab874ad99b696f4c997d6f5a4746',1,'EspServer']]]
];
