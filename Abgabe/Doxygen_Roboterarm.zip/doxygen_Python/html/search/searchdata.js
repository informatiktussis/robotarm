var indexSectionsWithContent =
{
  0: "_abcdefhijklmnopqrstuvwxy",
  1: "aw",
  2: "f",
  3: "f",
  4: "_cors",
  5: "abcdefhijklmnopqrstuvwxy"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables"
};

var indexSectionLabels =
{
  0: "Alle",
  1: "Klassen",
  2: "Namensbereiche",
  3: "Dateien",
  4: "Funktionen",
  5: "Variablen"
};

