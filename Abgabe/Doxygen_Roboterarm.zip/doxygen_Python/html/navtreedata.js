var NAVTREE =
[
  [ "Robot Arm", "index.html", [
    [ "Pakete", null, [
      [ "Pakete", "namespaces.html", "namespaces" ],
      [ "Paketfunktionen", "namespacemembers.html", [
        [ "Alle", "namespacemembers.html", null ],
        [ "Variablen", "namespacemembers_vars.html", null ]
      ] ]
    ] ],
    [ "Klassen", "annotated.html", [
      [ "Auflistung der Klassen", "annotated.html", "annotated_dup" ],
      [ "Klassen-Verzeichnis", "classes.html", null ],
      [ "Klassenhierarchie", "hierarchy.html", "hierarchy" ],
      [ "Klassen-Elemente", "functions.html", [
        [ "Alle", "functions.html", null ],
        [ "Funktionen", "functions_func.html", null ],
        [ "Variablen", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Dateien", null, [
      [ "Auflistung der Dateien", "files.html", "files" ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_f_i_n_a_l___g_u_i___w_l_a_n_8py.html"
];

var SYNCONMSG = 'Klicken um Panelsynchronisation auszuschalten';
var SYNCOFFMSG = 'Klicken um Panelsynchronisation einzuschalten';