var indexSectionsWithContent =
{
  0: "_abcdeflmprsw",
  1: "e",
  2: "ad",
  3: "abceflmprsw",
  4: "_ceprs",
  5: "e",
  6: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines",
  6: "pages"
};

var indexSectionLabels =
{
  0: "Alle",
  1: "Datenstrukturen",
  2: "Dateien",
  3: "Funktionen",
  4: "Variablen",
  5: "Makrodefinitionen",
  6: "Seiten"
};

