var searchData=
[
  ['setup',['setup',['../_arduino__kommentiert_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'Arduino_kommentiert.ino']]],
  ['setup_5fserver',['setup_server',['../class_esp_server.html#a7968cc44a6c9fff24b9020e1714c49f8',1,'EspServer']]],
  ['spezial_5ffunktion_5fhoch',['spezial_funktion_hoch',['../_arduino__kommentiert_8ino.html#ac03f54892f7473625ec7d6498ea5a010',1,'Arduino_kommentiert.ino']]],
  ['spezial_5ffunktion_5frunter',['spezial_funktion_runter',['../_arduino__kommentiert_8ino.html#abf7a5d6cd0eca7c0dacb61f5ef555beb',1,'Arduino_kommentiert.ino']]]
];
