var menudata={children:[
{text:"Hauptseite",url:"index.html"},
{text:"Datenstrukturen",url:"annotated.html",children:[
{text:"Datenstrukturen",url:"annotated.html"},
{text:"Datenstruktur-Verzeichnis",url:"classes.html"},
{text:"Klassenhierarchie",url:"inherits.html"},
{text:"Datenstruktur-Elemente",url:"functions.html",children:[
{text:"Alle",url:"functions.html"},
{text:"Funktionen",url:"functions_func.html"},
{text:"Variablen",url:"functions_vars.html"}]}]},
{text:"Dateien",url:"files.html",children:[
{text:"Auflistung der Dateien",url:"files.html"},
{text:"Datei-Elemente",url:"globals.html",children:[
{text:"Alle",url:"globals.html"},
{text:"Funktionen",url:"globals_func.html"},
{text:"Variablen",url:"globals_vars.html"},
{text:"Makrodefinitionen",url:"globals_defs.html"}]}]}]}
