var searchData=
[
  ['python_5fbutton_5fvar',['python_button_var',['../_arduino__kommentiert_8ino.html#a409d566aad8f36a68f5c2ec46ce59393',1,'Arduino_kommentiert.ino']]]
];
