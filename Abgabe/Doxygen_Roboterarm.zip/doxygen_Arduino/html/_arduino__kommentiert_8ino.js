var _arduino__kommentiert_8ino =
[
    [ "arm_hoch", "_arduino__kommentiert_8ino.html#a74bfcf85e5418694eb99df53d30c8fab", null ],
    [ "arm_runter", "_arduino__kommentiert_8ino.html#a5b873994166a952d81f787c307ca08d9", null ],
    [ "esp_serial", "_arduino__kommentiert_8ino.html#af690b3a6882292855c4091ede8039998", null ],
    [ "loop", "_arduino__kommentiert_8ino.html#afe461d27b9c48d5921c00d521181f12f", null ],
    [ "setup", "_arduino__kommentiert_8ino.html#a4fc01d736fe50cf5b977f755b675f11d", null ],
    [ "spezial_funktion_hoch", "_arduino__kommentiert_8ino.html#ac03f54892f7473625ec7d6498ea5a010", null ],
    [ "spezial_funktion_runter", "_arduino__kommentiert_8ino.html#abf7a5d6cd0eca7c0dacb61f5ef555beb", null ],
    [ "esp_server", "_arduino__kommentiert_8ino.html#a92309e3a6d185d9188757bac49168fe5", null ],
    [ "python_button_var", "_arduino__kommentiert_8ino.html#a409d566aad8f36a68f5c2ec46ce59393", null ],
    [ "servo1", "_arduino__kommentiert_8ino.html#ac5d2bea44c6318454db0e2639a4efe95", null ],
    [ "servo2", "_arduino__kommentiert_8ino.html#a6458146b8e54c3729bbee8c037921c72", null ],
    [ "servo3", "_arduino__kommentiert_8ino.html#a7c0244e667b5f7c873df01946f0767bd", null ],
    [ "servo4", "_arduino__kommentiert_8ino.html#a207f149c99b91a8bacd26b8b70dfc71c", null ],
    [ "servo_1pin", "_arduino__kommentiert_8ino.html#ac5b3a3df1bbdb6b2c8e8988c7373ad97", null ],
    [ "servo_2pin", "_arduino__kommentiert_8ino.html#a0fcb42829030c7eab1ede7429256f14d", null ],
    [ "servo_3pin", "_arduino__kommentiert_8ino.html#a006b96047ca9585e312d88690d5a95a3", null ],
    [ "servo_4pin", "_arduino__kommentiert_8ino.html#a5c0d394c06f48072ed4a5cf3f5f3b81b", null ],
    [ "speed_var", "_arduino__kommentiert_8ino.html#a8b03f5396d8e845086daab48dcaca5cb", null ]
];